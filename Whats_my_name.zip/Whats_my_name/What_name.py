from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/process', methods =['POST'])
def what_name():
    print "input received"
    name = request.form['name']
    print name
    return render_template('index.html')
app.run(debug=True)